switchPageCountUp = c(2, "'backfor'", "'b_pagination__link'", "'sc-bmyXtO jVmCmP sc-dnqmqq gBBUEN'", "' Next > '", "'mehr Jobs laden'", "'right'", "'b_linkarrow b_linkarrow--right bJS_pagebrowser_next'", "'paginationArrow sapIcon'","'backfor-more'", "'Zur nächsten Seite'", "'Nächste Seite'", "tablenav_top_nextlink_66856", "'Next >'", "'›'", "'icon itnav_next'",
                      "nächste Seite", "'View Next'", "'halflings halflings-menu-right'", "'>'", "'fa fa-angle-right'", "'»'", "2", "'2'", "'pagerElement pager-next'",
                      "'Nächste'", "'Next Page'", "'icon-double-arrow-r'", "'nächste'", "'next'", "'Weiter'", "'Nächste 100'", "'Load more'",
                      "'Next'", "''")

switchPageLoadMore = c("'MORE RESULTS'", "'pagination-button btn'", "'Mehr anzeigen'","'button highlight red borderRadius6 jsbutton'", "'load-more'", "'more results'", "'Jobs laden'",
                       "'Mehr laden'", "'Mehr Jobs anzeigen'", "'icon-arrow-down2'" ,"'Weitere anzeigen'" ,"'button more showMore'", "'load more...'", "'weitere Jobs laden'", "'Show more results'", "'Weitere laden'", "'Alle laden'",  "'Weitere'",
                       "'Show more jobs'", "'Mehr Jobs laden'", "'Zeige mehr'",
                       "'Weitere Jobangebote laden'")


save(switchPageCountUp, file = "SteveAI/switchPageCountUp.RData")
save(switchPageLoadMore, file = "SteveAI/switchPageLoadMore.RData")

