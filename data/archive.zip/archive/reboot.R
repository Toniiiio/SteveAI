system("sudo -kS reboot", input = "Donthack1")
